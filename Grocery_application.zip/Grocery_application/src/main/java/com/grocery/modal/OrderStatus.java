package com.grocery.modal;

public enum OrderStatus {
	PAID
}
